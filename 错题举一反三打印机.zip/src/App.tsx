import React, { useState, useEffect } from 'react';
import { Camera, BookOpen, Trash2, Printer, ChevronRight, CheckCircle2, RotateCcw, Plus, Save, FileText, Loader2, LogIn, LogOut } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { auth, signIn } from './lib/firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import RecognitionView from './components/RecognitionView';
import NotebookView from './components/NotebookView';

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'recognition' | 'notebook'>('recognition');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const handleSignIn = async () => {
    try {
      await signIn();
    } catch (err) {
      console.error(err);
    }
  };

  const handleSignOut = () => {
    signOut(auth);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-50">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 rounded-3xl shadow-xl max-w-md w-full text-center space-y-6"
        >
          <div className="w-20 h-20 bg-indigo-100 rounded-2xl flex items-center justify-center mx-auto">
            <BookOpen className="w-10 h-10 text-indigo-600" />
          </div>
          <h1 className="text-3xl font-bold text-slate-800">错题举一反三打印机</h1>
          <p className="text-slate-500 text-lg">
            全科通用的错题学习工具。拍照识别错题，智能生成变式题目，助你深度掌握知识点。
          </p>
          <button
            onClick={handleSignIn}
            className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-semibold flex items-center justify-center gap-3 transition-colors shadow-lg shadow-indigo-200"
          >
            <LogIn className="w-5 h-5" />
            开启学习之旅
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8F9FC] text-slate-900 pb-24">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 h-16 bg-white/80 backdrop-blur-md border-b border-slate-200 z-50 px-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
            <BookOpen className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-xl font-bold text-slate-800">错题打印机</h1>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm font-medium text-slate-500 hidden sm:inline">{user.displayName}</span>
          <button 
            onClick={handleSignOut}
            className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-500"
            title="退出登录"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto max-w-4xl pt-24 px-4">
        <AnimatePresence mode="wait">
          {activeTab === 'recognition' ? (
            <motion.div
              key="recognition"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.2 }}
            >
              <RecognitionView onSaveSuccess={() => setActiveTab('notebook')} />
            </motion.div>
          ) : (
            <motion.div
              key="notebook"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
            >
              <NotebookView />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-white/90 backdrop-blur-lg border border-slate-200 px-2 py-2 rounded-2xl shadow-2xl z-50 flex items-center gap-2">
        <button
          onClick={() => setActiveTab('recognition')}
          className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all ${
            activeTab === 'recognition' 
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200Scale-105' 
              : 'text-slate-500 hover:bg-slate-50'
          }`}
        >
          <Camera className="w-5 h-5" />
          <span>错题识别</span>
        </button>
        <button
          onClick={() => setActiveTab('notebook')}
          className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all ${
            activeTab === 'notebook' 
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200 scale-105' 
              : 'text-slate-500 hover:bg-slate-50'
          }`}
        >
          <BookOpen className="w-5 h-5" />
          <span>错题本</span>
        </button>
      </nav>
    </div>
  );
}
