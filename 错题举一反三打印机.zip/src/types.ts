export interface VariantProblem {
  question: string;
  answer: string;
  analysis: string;
}

export interface MistakeRecord {
  id?: string;
  userId: string;
  subject: string;
  grade: string;
  originalText: string;
  originalAnswer?: string;
  originalAnalysis?: string;
  originalImageUrl?: string;
  knowledgePoint: string;
  variants: VariantProblem[];
  createdAt: any; // Firestore Timestamp
  updatedAt: any;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}
