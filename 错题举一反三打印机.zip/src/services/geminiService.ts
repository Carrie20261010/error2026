import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function performOCR(base64Image: string) {
  const model = "gemini-3-flash-preview";
  
  const prompt = `
    你是一个专业的学科题目识别助手。请识别图中题目内容。
    要求：
    1. 提取所有可见文本，包括题目主干、选项。
    2. 数学公式请使用 LaTeX 格式（用 $ 包裹）。
    3. 清晰区分题干和选项。
    4. 如果图中包含解题过程或用户答案，也请一并提取并标注为“原答案”。
    直接返回识别后的文本内容。
  `;

  const imagePart = {
    inlineData: {
      mimeType: "image/jpeg",
      data: base64Image.split(",")[1],
    },
  };

  const response = await ai.models.generateContent({
    model,
    contents: { parts: [imagePart, { text: prompt }] },
  });

  return response.text;
}

export async function generateMistakeAnalysis(mistakeText: string) {
  const model = "gemini-3-flash-preview";

  const prompt = `
    基于以下错题内容，请完成：
    1. 判断其核心知识点（例如“一元二次方程根的判别式”）。
    2. 判断所属学科（仅限：语文、数学、英语、物理、化学、生物、历史、地理、政治。如果不确定，请返回“综合”）。
    3. 生成 3 道举一反三的相似变式题目。
    4. 每道题（包括原错题本身和 3 道变式题）都请附带正确答案和侧重易错点的解析。
    
    错题内容：
    ${mistakeText}
  `;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          knowledgePoint: { type: Type.STRING },
          subject: { type: Type.STRING, description: "判定后的学科名称" },
          originalAnswer: { type: Type.STRING, description: "原错题的正确答案" },
          originalAnalysis: { type: Type.STRING, description: "原错题的易错点解析" },
          variants: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING, description: "包含题干和选项的完整题目，数学公式用 LaTeX $ 分隔" },
                answer: { type: Type.STRING, description: "正确答案" },
                analysis: { type: Type.STRING, description: "侧重易错点的解析" }
              },
              required: ["question", "answer", "analysis"]
            }
          }
        },
        required: ["knowledgePoint", "subject", "originalAnswer", "originalAnalysis", "variants"]
      }
    }
  });

  if (!response.text) throw new Error("Failed to generate response");
  return JSON.parse(response.text);
}
