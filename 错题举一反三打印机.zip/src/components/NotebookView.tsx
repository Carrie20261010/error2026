import React, { useState, useEffect } from 'react';
import { Printer, Trash2, ChevronRight, Loader2, CheckSquare, Square, FileText, Search, X, BookOpen, AlertCircle, RotateCcw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, where, orderBy, onSnapshot, deleteDoc, doc } from 'firebase/firestore';
import { auth, db, handleFirestoreError } from '../lib/firebase';
import { MistakeRecord, OperationType } from '../types';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { createRoot } from 'react-dom/client';

export default function NotebookView() {
  const [records, setRecords] = useState<MistakeRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [isPrinting, setIsPrinting] = useState(false);
  const [detailItem, setDetailItem] = useState<MistakeRecord | null>(null);
  const [pdfColumns, setPdfColumns] = useState<1 | 2 | 3>(1);

  // Filters
  const [subjectFilter, setSubjectFilter] = useState<string>('全部');
  const [gradeFilter, setGradeFilter] = useState<string>('全部');

  const [pdfContentOptions, setPdfContentOptions] = useState({
    showKnowledgePoint: true,
    paperName: '错题变式练习',
    answerPlacement: 'after-question' as 'after-question' | 'end-of-paper' | 'none',
    fontSize: 'medium' as 'small' | 'medium' | 'large',
    showOriginal: true,
    showOriginalAnswer: true,
    showVariants: true
  });
  const [showPdfOptions, setShowPdfOptions] = useState(false);

  const SUBJECTS = ['全部', '语文', '数学', '英语', '物理', '化学', '生物', '历史', '地理', '政治', '综合'];
  const GRADES = ['全部', '一年级', '二年级', '三年级', '四年级', '五年级', '六年级', '七年级', '八年级', '九年级'];

  useEffect(() => {
    if (!auth.currentUser) return;

    const q = query(
      collection(db, 'mistakes'),
      where('userId', '==', auth.currentUser.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, 
      (snapshot) => {
        const docs = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as MistakeRecord));
        setRecords(docs);
        setLoading(false);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'mistakes');
      }
    );

    return unsubscribe;
  }, []);

  const toggleSelection = (id: string) => {
    const newSelection = new Set(selectedIds);
    if (newSelection.has(id)) newSelection.delete(id);
    else newSelection.add(id);
    setSelectedIds(newSelection);
  };

  const selectAll = () => {
    if (selectedIds.size === filteredRecords.length) setSelectedIds(new Set());
    else setSelectedIds(new Set(filteredRecords.map(r => r.id!)));
  };

  const filteredRecords = records.filter(r => {
    const sMatch = subjectFilter === '全部' || r.subject === subjectFilter;
    const gMatch = gradeFilter === '全部' || r.grade === gradeFilter;
    return sMatch && gMatch;
  });

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('确定要删除这条记录吗？')) return;
    try {
      await deleteDoc(doc(db, 'mistakes', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `mistakes/${id}`);
    }
  };

  const generatePDF = async () => {
    if (selectedIds.size === 0) return;
    setIsPrinting(true);
    
    // Create hidden container for rendering
    const printContainer = document.createElement('div');
    printContainer.style.position = 'fixed';
    printContainer.style.left = '-10000px';
    printContainer.style.top = '0';
    printContainer.style.width = '210mm'; // A4 width
    // printContainer.style.padding = '20mm'; // Handled in React component
    printContainer.style.backgroundColor = 'white';
    document.body.appendChild(printContainer);

    const pdfContent = records.filter(r => selectedIds.has(r.id!));
    
    const fontSizes = {
      small: { title: '12pt', label: '9pt', content: '8pt', analysis: '7pt' },
      medium: { title: '14pt', label: '10pt', content: '10pt', analysis: '9pt' },
      large: { title: '16pt', label: '12pt', content: '12pt', analysis: '11pt' }
    };

    const currentFs = fontSizes[pdfContentOptions.fontSize];

    // Internal component to handle rendering with ReactMarkdown & KaTeX
    const PrintTemplate = () => (
      <div style={{ padding: '15mm', color: 'black', fontFamily: 'serif' }} className="markdown-body">
        <h2 style={{ textAlign: 'center', borderBottom: '2px solid #333', paddingBottom: '10px', marginBottom: '30px' }}>
          {pdfContentOptions.paperName}
        </h2>
        <div style={{ columnCount: pdfColumns, columnGap: '12mm', columnRule: '1px solid #eee' }}>
          {pdfContent.map((record, index) => (
            <div key={record.id} style={{ marginBottom: '30px', breakInside: 'avoid', borderBottom: '1px solid #eee', paddingBottom: '20px' }}>
              {pdfContentOptions.showKnowledgePoint && (
                <div style={{ fontSize: currentFs.title, fontWeight: 'bold', marginBottom: '8px', color: '#1e293b' }}>
                  记录 {index + 1}: {record.knowledgePoint}
                </div>
              )}

              {pdfContentOptions.showOriginal && (
                <div style={{ marginBottom: pdfContentOptions.showVariants ? '20px' : '0' }}>
                  <div style={{ fontWeight: 'bold', marginTop: '10px', display: 'block', background: '#f8fafc', padding: '4px', fontSize: currentFs.label }}>
                    【原错题】
                  </div>
                  <div style={{ fontSize: currentFs.content, lineHeight: 1.6, color: '#334155', marginTop: '8px' }}>
                    <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>
                      {record.originalText}
                    </ReactMarkdown>
                  </div>
                  {pdfContentOptions.answerPlacement === 'after-question' && pdfContentOptions.showOriginalAnswer && record.originalAnswer && (
                    <div style={{ marginTop: '10px', borderLeft: '2px solid #6366f1', paddingLeft: '10px', fontSize: currentFs.content }}>
                      <div style={{ color: '#475569', fontStyle: 'italic', fontSize: currentFs.analysis }}>
                        参考答案：{record.originalAnswer}
                      </div>
                      <div style={{ fontWeight: 'bold', marginTop: '10px', display: 'block', background: '#f8fafc', padding: '4px', fontSize: currentFs.label }}>
                        易错点分析：
                      </div>
                      <div style={{ fontSize: currentFs.analysis, color: '#64748b', marginTop: '4px' }}>
                        <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{record.originalAnalysis || ''}</ReactMarkdown>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {pdfContentOptions.showVariants && (
                <div>
                  <div style={{ fontWeight: 'bold', marginTop: '15px', display: 'block', background: '#f8fafc', padding: '4px', fontSize: currentFs.label }}>
                    【举一反三】
                  </div>
                  {record.variants.map((v, vIdx) => (
                    <div key={vIdx} style={{ marginTop: '15px', borderLeft: '2px solid #6366f1', paddingLeft: '10px', fontSize: currentFs.content }}>
                      <div><strong>题目 {vIdx + 1}：</strong></div>
                      <div style={{ marginTop: '4px' }}>
                        <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{v.question}</ReactMarkdown>
                      </div>
                      
                      {pdfContentOptions.answerPlacement === 'after-question' && (
                        <>
                          <div style={{ marginTop: '4px', color: '#475569', fontStyle: 'italic', fontSize: currentFs.analysis }}>
                            参考答案：{v.answer}
                          </div>
                          <div style={{ fontWeight: 'bold', marginTop: '10px', display: 'block', background: '#f8fafc', padding: '4px', fontSize: currentFs.label }}>
                            易错点分析：
                          </div>
                          <div style={{ fontSize: currentFs.analysis, color: '#64748b', marginTop: '4px' }}>
                            <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{v.analysis}</ReactMarkdown>
                          </div>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        {pdfContentOptions.answerPlacement === 'end-of-paper' && (
          <div style={{ marginTop: '40px', borderTop: '4px double #333', paddingTop: '20px', breakBefore: 'page' }}>
            <h3 style={{ textAlign: 'center', marginBottom: '20px' }}>答案与解析（Answer Key）</h3>
            {pdfContent.map((record, index) => (
              <div key={`ans-${record.id}`} style={{ marginBottom: '25px' }}>
                <div style={{ fontWeight: 'bold', borderBottom: '1px solid #ddd', fontSize: currentFs.title }}>
                  第 {index + 1} 组：{record.knowledgePoint}
                </div>
                
                {pdfContentOptions.showOriginal && pdfContentOptions.showOriginalAnswer && record.originalAnswer && (
                  <div style={{ marginTop: '10px', fontSize: currentFs.analysis }}>
                    <div style={{ fontWeight: 'bold', color: '#6366f1' }}>原题答案与解析：</div>
                    <strong>答案：</strong> {record.originalAnswer}
                    <div style={{ color: '#666', marginTop: '2px' }}>
                      解析：<ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{record.originalAnalysis || ''}</ReactMarkdown>
                    </div>
                  </div>
                )}

                {pdfContentOptions.showVariants && (
                  <div style={{ marginTop: '10px' }}>
                    <div style={{ fontWeight: 'bold', color: '#6366f1' }}>变式题答案与解析：</div>
                    {record.variants.map((v, vIdx) => (
                      <div key={vIdx} style={{ marginTop: '10px', fontSize: currentFs.analysis }}>
                        <strong>变式 {vIdx + 1} 答案：</strong> {v.answer}
                        <div style={{ color: '#666', marginTop: '2px' }}>
                          解析：<ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{v.analysis}</ReactMarkdown>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    );

    const root = createRoot(printContainer);
    root.render(<PrintTemplate />);

    // Give it a moment to render KaTeX and Markdown
    await new Promise(resolve => setTimeout(resolve, 800));

    try {
      const canvas = await html2canvas(printContainer, { 
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff'
      });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      
      // If height is more than one page, we might need multiple pages, 
      // but html2canvas on one giant div generates one giant image.
      // For simplicity, we just place it. Multi-page support with html2canvas can be complex.
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`错题本_${new Date().toLocaleDateString()}.pdf`);
    } catch (err) {
      console.error(err);
      alert('PDF 生成失败');
    } finally {
      root.unmount();
      document.body.removeChild(printContainer);
      setIsPrinting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <Loader2 className="w-10 h-10 animate-spin text-indigo-600" />
        <p className="text-slate-500 font-medium">加载历史记录中...</p>
      </div>
    );
  }

  if (records.length === 0) {
    return (
      <div className="text-center py-20 space-y-4">
        <div className="w-20 h-20 bg-slate-100 rounded-3xl flex items-center justify-center mx-auto">
          <BookOpen className="w-10 h-10 text-slate-400" />
        </div>
        <h3 className="text-xl font-bold text-slate-800">暂无错题记录</h3>
        <p className="text-slate-500">点击下方的“错题识别”开启第一条记录吧</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12">
      {/* Filters Bar */}
      <div className="flex flex-wrap gap-4 items-center bg-white border border-slate-200 p-4 rounded-2xl">
        <div className="flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-slate-400" />
          <span className="text-xs font-bold text-slate-500">学科：</span>
          <div className="flex flex-wrap gap-1">
            {SUBJECTS.map(s => (
              <button
                key={s}
                onClick={() => setSubjectFilter(s)}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                  subjectFilter === s ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
        <div className="w-px h-6 bg-slate-200 hidden md:block"></div>
        <div className="flex items-center gap-2">
          <ChevronRight className="w-4 h-4 text-slate-400" />
          <span className="text-xs font-bold text-slate-500">年级：</span>
          <select 
            value={gradeFilter}
            onChange={(e) => setGradeFilter(e.target.value)}
            className="text-xs font-bold bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 outline-none focus:ring-2 focus:ring-indigo-500 text-slate-700"
          >
            {GRADES.map(g => <option key={g} value={g}>{g}</option>)}
          </select>
        </div>
      </div>

      {/* List Header Actions */}
      <div className="sticky top-16 bg-[#F8F9FC]/80 backdrop-blur-md py-4 z-40 space-y-4 px-2">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button 
              onClick={selectAll}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors text-sm font-semibold"
            >
              {selectedIds.size === filteredRecords.length ? <CheckSquare className="w-4 h-4 text-indigo-600" /> : <Square className="w-4 h-4 text-slate-400" />}
              {selectedIds.size === filteredRecords.length ? '取消全选' : '全选'}
            </button>
            <span className="text-sm text-slate-500 font-medium">
              已选择 {selectedIds.size} 条记录
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowPdfOptions(!showPdfOptions)}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-50"
            >
              <Search className="w-4 h-4" />
              打印选项
              <ChevronRight className={`w-4 h-4 transition-transform ${showPdfOptions ? 'rotate-90' : ''}`} />
            </button>
            
            <button
              onClick={generatePDF}
              disabled={selectedIds.size === 0 || isPrinting}
              className="flex items-center gap-2 px-6 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all disabled:opacity-50 disabled:grayscale font-bold shadow-lg shadow-indigo-100"
            >
              {isPrinting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Printer className="w-4 h-4" />}
              导出 PDF
            </button>
          </div>
        </div>

        {/* Action Panel */}
        <AnimatePresence>
          {showPdfOptions && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="bg-white border border-slate-200 rounded-2xl p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* Columns */}
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">排版栏数</label>
                  <div className="flex gap-2">
                    {[1, 2, 3].map((cols) => (
                      <button
                        key={cols}
                        onClick={() => setPdfColumns(cols as any)}
                        className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all border ${
                          pdfColumns === cols 
                            ? 'bg-indigo-600 text-white border-indigo-600' 
                            : 'bg-white text-slate-500 border-slate-200 hover:border-indigo-200'
                        }`}
                      >
                        {cols} 栏
                      </button>
                    ))}
                  </div>
                </div>

                {/* Display Content */}
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">显示内容</label>
                  <div className="flex flex-col gap-2">
                    <label className="flex items-center gap-2 text-xs font-medium text-slate-600 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={pdfContentOptions.showKnowledgePoint} 
                        onChange={e => setPdfContentOptions({...pdfContentOptions, showKnowledgePoint: e.target.checked})}
                        className="rounded text-indigo-600 w-4 h-4"
                      />
                      显示知识点
                    </label>
                    <label className="flex items-center gap-2 text-xs font-medium text-slate-600 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={pdfContentOptions.showOriginal} 
                        onChange={e => setPdfContentOptions({...pdfContentOptions, showOriginal: e.target.checked})}
                        className="rounded text-indigo-600 w-4 h-4"
                      />
                      显示原错题
                    </label>
                    <label className="flex items-center gap-2 text-xs font-medium text-slate-600 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={pdfContentOptions.showOriginalAnswer} 
                        onChange={e => setPdfContentOptions({...pdfContentOptions, showOriginalAnswer: e.target.checked})}
                        className="rounded text-indigo-600 w-4 h-4"
                      />
                      显示原题答案
                    </label>
                    <label className="flex items-center gap-2 text-xs font-medium text-slate-600 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={pdfContentOptions.showVariants} 
                        onChange={e => setPdfContentOptions({...pdfContentOptions, showVariants: e.target.checked})}
                        className="rounded text-indigo-600 w-4 h-4"
                      />
                      显示举一反三
                    </label>
                    <input 
                      type="text" 
                      placeholder="试卷名称..."
                      value={pdfContentOptions.paperName}
                      onChange={e => setPdfContentOptions({...pdfContentOptions, paperName: e.target.value})}
                      className="text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg w-full"
                    />
                  </div>
                </div>

                {/* Answer Placement */}
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">答案设置</label>
                  <div className="flex flex-col gap-2">
                    <button
                      onClick={() => setPdfContentOptions({...pdfContentOptions, answerPlacement: 'after-question'})}
                      className={`py-2 rounded-lg text-xs font-bold transition-all border ${
                        pdfContentOptions.answerPlacement === 'after-question' 
                          ? 'bg-indigo-600 text-white border-indigo-600' 
                          : 'bg-white text-slate-500 border-slate-200 hover:border-indigo-200'
                      }`}
                    >
                      随题显示
                    </button>
                    <button
                      onClick={() => setPdfContentOptions({...pdfContentOptions, answerPlacement: 'end-of-paper'})}
                      className={`py-2 rounded-lg text-xs font-bold transition-all border ${
                        pdfContentOptions.answerPlacement === 'end-of-paper' 
                          ? 'bg-indigo-600 text-white border-indigo-600' 
                          : 'bg-white text-slate-500 border-slate-200 hover:border-indigo-200'
                      }`}
                    >
                      按试卷后显示
                    </button>
                    <button
                      onClick={() => setPdfContentOptions({...pdfContentOptions, answerPlacement: 'none'})}
                      className={`py-2 rounded-lg text-xs font-bold transition-all border ${
                        pdfContentOptions.answerPlacement === 'none' 
                          ? 'bg-indigo-600 text-white border-indigo-600' 
                          : 'bg-white text-slate-500 border-slate-200 hover:border-indigo-200'
                      }`}
                    >
                      不需要答案
                    </button>
                  </div>
                </div>

                {/* Font Size */}
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">文字字号</label>
                  <div className="flex gap-2">
                    {(['small', 'medium', 'large'] as const).map((size) => (
                      <button
                        key={size}
                        onClick={() => setPdfContentOptions({...pdfContentOptions, fontSize: size})}
                        className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all border ${
                          pdfContentOptions.fontSize === size 
                            ? 'bg-indigo-600 text-white border-indigo-600' 
                            : 'bg-white text-slate-500 border-slate-200 hover:border-indigo-200'
                        }`}
                      >
                        {size === 'small' ? '小' : size === 'medium' ? '中' : '大'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Grid of Cards */}
      <div className="grid gap-4">
        {filteredRecords.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-slate-200">
            <p className="text-slate-400">没有找到匹配的错题记录</p>
          </div>
        ) : (
          filteredRecords.map((record) => (
            <motion.div
              key={record.id}
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              onClick={() => setDetailItem(record)}
              className={`group relative bg-white rounded-3xl p-5 border transition-all cursor-pointer hover:shadow-xl hover:-translate-y-1 ${
                selectedIds.has(record.id!) ? 'border-indigo-600 ring-2 ring-indigo-50 border-transparent shadow-md' : 'border-slate-200 shadow-sm'
              }`}
            >
              <div className="flex items-start gap-4">
                <button 
                  onClick={(e) => { e.stopPropagation(); toggleSelection(record.id!); }}
                  className="mt-1 transition-transform active:scale-90"
                >
                  {selectedIds.has(record.id!) ? (
                    <CheckSquare className="w-6 h-6 text-indigo-600 fill-indigo-50" />
                  ) : (
                    <Square className="w-6 h-6 text-slate-300" />
                  )}
                </button>
                <div className="flex-1 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                       <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-md uppercase tracking-wider">
                        {record.subject || '综合'}
                      </span>
                      <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2 py-1 rounded-md">
                        {record.grade || '未设置'}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {record.createdAt?.toDate().toLocaleDateString()}
                    </span>
                  </div>
                  <h4 className="text-slate-800 font-semibold line-clamp-2 leading-relaxed">
                    {record.knowledgePoint}
                  </h4>
                  <div className="flex items-center gap-4 text-xs text-slate-500 pt-1">
                    <span className="flex items-center gap-1">
                      <FileText className="w-3 h-3" />
                      3 道变式题
                    </span>
                  </div>
                </div>
                <button 
                  onClick={(e) => handleDelete(record.id!, e)}
                  className="opacity-0 group-hover:opacity-100 p-2 text-slate-300 hover:text-red-500 transition-all rounded-full hover:bg-red-50"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          ))
        )}
      </div>

      {/* Detail Modal */}
      <AnimatePresence>
        {detailItem && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-4"
          >
            <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={() => setDetailItem(null)} />
            <motion.div 
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 100, opacity: 0 }}
              className="relative w-full max-w-2xl bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] shadow-2xl max-h-[90vh] overflow-hidden flex flex-col"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white/80 backdrop-blur-md z-1">
                <div>
                  <h3 className="font-bold text-xl text-slate-800">{detailItem.knowledgePoint}</h3>
                  <p className="text-xs text-slate-400 mt-0.5">保存日期：{detailItem.createdAt?.toDate().toLocaleString()}</p>
                </div>
                <button 
                  onClick={() => setDetailItem(null)}
                  className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-6 space-y-8 pb-12">
                <section className="space-y-3">
                  <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                     <AlertCircle className="w-4 h-4" />
                     原题回顾
                  </h4>
                  <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100 text-slate-700 leading-relaxed shadow-inner">
                    <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>
                      {detailItem.originalText}
                    </ReactMarkdown>

                    {detailItem.originalAnswer && (
                      <div className="mt-6 border-t border-slate-200 pt-4 space-y-4">
                        <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
                          <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest">原题答案</span>
                          <p className="mt-1 font-bold text-slate-800">{detailItem.originalAnswer}</p>
                        </div>
                        <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100">
                          <span className="text-[10px] font-bold text-amber-600 uppercase tracking-widest italic">原题解析</span>
                          <div className="mt-1 text-slate-700 text-sm leading-relaxed">
                             <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>
                               {detailItem.originalAnalysis || ''}
                             </ReactMarkdown>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </section>

                <section className="space-y-6">
                  <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                     <RotateCcw className="w-4 h-4" />
                     举一反三变式
                  </h4>
                  <div className="space-y-4">
                    {detailItem.variants.map((variant, idx) => (
                      <div key={idx} className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
                         <span className="inline-flex w-8 h-8 bg-indigo-600 text-white rounded-lg items-center justify-center font-bold">
                           {idx + 1}
                         </span>
                         <div className="prose prose-slate max-w-none">
                            <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>
                              {variant.question}
                            </ReactMarkdown>
                         </div>
                         <div className="grid grid-cols-1 gap-3 pt-2">
                           <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
                             <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest">正确答案</span>
                             <p className="mt-1 font-bold text-slate-800">{variant.answer}</p>
                           </div>
                           <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100">
                             <span className="text-[10px] font-bold text-amber-600 uppercase tracking-widest italic">易错点解析</span>
                             <div className="mt-1 text-slate-700 text-sm leading-relaxed">
                                <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>
                                  {variant.analysis}
                                </ReactMarkdown>
                             </div>
                           </div>
                         </div>
                      </div>
                    ))}
                  </div>
                </section>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
