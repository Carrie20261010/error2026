import React, { useState, useRef } from 'react';
import { Camera, Image as ImageIcon, Loader2, RotateCcw, Plus, Save, CheckCircle2, ChevronRight, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import 'katex/dist/katex.min.css';
import { performOCR, generateMistakeAnalysis } from '../services/geminiService';
import { auth, db, handleFirestoreError } from '../lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { OperationType, VariantProblem } from '../types';

export default function RecognitionView({ onSaveSuccess }: { onSaveSuccess: () => void }) {
  const [image, setImage] = useState<string | null>(null);
  const [ocrText, setOcrText] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [step, setStep] = useState<'upload' | 'ocr' | 'analysis'>('upload');
  const [analysis, setAnalysis] = useState<{ 
    knowledgePoint: string, 
    subject: string,
    originalAnswer: string,
    originalAnalysis: string,
    variants: VariantProblem[] 
  } | null>(null);
  const [selectedGrade, setSelectedGrade] = useState('一年级');
  const [isSaving, setIsSaving] = useState(false);
  
  const GRADES = ['一年级', '二年级', '三年级', '四年级', '五年级', '六年级', '七年级', '八年级', '九年级'];
  const SUBJECTS = ['语文', '数学', '英语', '物理', '化学', '生物', '历史', '地理', '政治', '综合'];

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        startOCR(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const startOCR = async (base64: string) => {
    setIsProcessing(true);
    try {
      const text = await performOCR(base64);
      setOcrText(text || '');
      setStep('ocr');
    } catch (err) {
      console.error(err);
      alert('识别失败，请重试');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleAnalysis = async () => {
    setIsProcessing(true);
    try {
      const result = await generateMistakeAnalysis(ocrText);
      setAnalysis(result);
      setStep('analysis');
    } catch (err) {
      console.error(err);
      alert('生成失败，请重试');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSave = async () => {
    if (!analysis || !auth.currentUser) return;
    setIsSaving(true);
    try {
      await addDoc(collection(db, 'mistakes'), {
        userId: auth.currentUser.uid,
        subject: analysis.subject,
        grade: selectedGrade,
        originalText: ocrText,
        originalAnswer: analysis.originalAnswer,
        originalAnalysis: analysis.originalAnalysis,
        knowledgePoint: analysis.knowledgePoint,
        variants: analysis.variants,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      onSaveSuccess();
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'mistakes');
    } finally {
      setIsSaving(false);
    }
  };

  const reset = () => {
    setImage(null);
    setOcrText('');
    setAnalysis(null);
    setStep('upload');
  };

  return (
    <div className="space-y-6">
      {/* Upload Section */}
      {step === 'upload' && (
        <section className="bg-white rounded-3xl p-8 border-2 border-dashed border-slate-200 text-center space-y-6">
          <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto">
            <Camera className="w-8 h-8" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-slate-800">拍照或上传错题</h2>
            <p className="text-slate-500 mt-2">支持全科题目识别，包含数学公式与符号</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-semibold flex items-center justify-center gap-2 hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100"
            >
              <Plus className="w-5 h-5" />
              选择图片
            </button>
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              onChange={handleImageUpload} 
            />
          </div>
        </section>
      )}

      {/* OCR & Edit Section */}
      {step === 'ocr' && (
        <motion.section 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden"
        >
          <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-500" />
              识别结果确认
            </h3>
            <button onClick={reset} className="text-slate-400 hover:text-slate-600">
              <X className="w-5 h-5" />
            </button>
          </div>
          
          <div className="p-6 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-500 uppercase tracking-wider">原始图片</label>
                <div className="aspect-video bg-slate-100 rounded-2xl overflow-hidden border border-slate-200 flex items-center justify-center relative">
                  {image && <img src={image} alt="Original" className="object-contain w-full h-full" />}
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-500 uppercase tracking-wider">文字识别结果</label>
                <textarea
                  value={ocrText}
                  onChange={(e) => setOcrText(e.target.value)}
                  className="w-full h-[200px] p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all font-mono text-sm leading-relaxed"
                  placeholder="如果识别不全，请手动补全..."
                />
              </div>
            </div>

            <div className="pt-4 flex justify-end gap-4">
              <button
                onClick={reset}
                className="px-6 py-3 border border-slate-200 text-slate-600 rounded-xl font-semibold hover:bg-slate-50 transition-colors"
              >
                重新上传
              </button>
              <button
                onClick={handleAnalysis}
                disabled={isProcessing || !ocrText}
                className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-semibold flex items-center gap-2 hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-100"
              >
                {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <ChevronRight className="w-5 h-5" />}
                生成举一反三
              </button>
            </div>
          </div>
        </motion.section>
      )}

      {/* Analysis & Save Section */}
      {step === 'analysis' && analysis && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">学科</label>
                  <select 
                    value={analysis.subject}
                    onChange={(e) => setAnalysis({...analysis, subject: e.target.value})}
                    className="text-sm font-bold bg-indigo-50 text-indigo-700 border border-indigo-100 rounded-lg px-3 py-1 outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">年级</label>
                  <select 
                    value={selectedGrade}
                    onChange={(e) => setSelectedGrade(e.target.value)}
                    className="text-sm font-bold bg-slate-50 text-slate-700 border border-slate-200 rounded-lg px-3 py-1 outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    {GRADES.map(g => <option key={g} value={g}>{g}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-md uppercase tracking-wider block w-fit">知识点</span>
                  <h2 className="text-xl font-bold text-slate-800">{analysis.knowledgePoint}</h2>
                </div>
              </div>
              <button
                onClick={handleSave}
                disabled={isSaving}
                className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-semibold flex items-center gap-2 hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-100"
              >
                {isSaving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                保存到错题本
              </button>
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 italic text-slate-500 text-sm">
              识别内容：{ocrText.substring(0, 150)}{ocrText.length > 150 ? '...' : ''}
            </div>
          </div>

          <div className="grid gap-6">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2 px-2">
              <RotateCcw className="w-5 h-5 text-indigo-600" />
              举一反三演练（3道题）
            </h3>
            {analysis.variants.map((variant, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4"
              >
                <div className="flex items-start justify-between">
                  <span className="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center font-bold text-slate-500">
                    {idx + 1}
                  </span>
                </div>
                <div className="prose prose-slate max-w-none">
                  <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>
                    {variant.question}
                  </ReactMarkdown>
                </div>
                <div className="mt-4 p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
                  <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider">标准答案</span>
                  <p className="mt-1 font-semibold text-slate-800">{variant.answer}</p>
                </div>
                <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100">
                  <span className="text-xs font-bold text-amber-600 uppercase tracking-wider italic flex items-center gap-1">
                    易错点分析
                  </span>
                  <div className="mt-1 text-slate-700 text-sm leading-relaxed">
                     <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>
                      {variant.analysis}
                    </ReactMarkdown>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="flex justify-center pt-4">
            <button
               onClick={handleAnalysis}
               className="flex items-center gap-2 text-slate-500 hover:text-indigo-600 transition-colors font-medium"
            >
              <RotateCcw className="w-4 h-4" />
              对题目不满意？重新生成
            </button>
          </div>
        </motion.div>
      )}

      {/* Loading Overlay */}
      <AnimatePresence>
        {isProcessing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-white/60 backdrop-blur-sm z-[100] flex flex-col items-center justify-center"
          >
            <div className="bg-white p-8 rounded-3xl shadow-2xl flex flex-col items-center gap-4 text-center border border-slate-100">
              <Loader2 className="w-12 h-12 text-indigo-600 animate-spin" />
              <div>
                <p className="font-bold text-slate-800 text-lg">正在智能解析中...</p>
                <p className="text-slate-500 text-sm mt-1">这可能需要几秒钟，为您匹配最高质量的变式题</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
